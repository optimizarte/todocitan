# Todacitan · app nativa Android

Proyecto Capacitor. El APK se compila solo en GitHub Actions (pestaña **Actions → Compilar APK Android**)
y se publica en **Releases**. Las alarmas las programa el sistema Android (notificaciones locales exactas).

- `www/index.html` — la app (misma que la web, con rama nativa)
- `scripts/build-android.mjs` — prepara el proyecto Android (permisos, firma, sonidos, iconos)
- `resources/` — sonidos de alarma (WAV) e iconos propios
- `keystore/` — clave de firma fija: permite instalar actualizaciones encima sin perder los datos
