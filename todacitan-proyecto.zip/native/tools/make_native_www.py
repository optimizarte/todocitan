"""Genera www/index.html (versión nativa) a partir de la app web, añadiendo
alarmas programadas por el sistema Android, acción 'Presa feta' en la notificación,
exportación por 'Compartir' y márgenes seguros. Cada sustitución se verifica."""
import sys

SRC, DST = sys.argv[1], sys.argv[2]
h = open(SRC, encoding="utf-8").read()

def rep(old, new, count=1, first_only=False):
    global h
    n = h.count(old)
    assert n == count, f"esperaba {count} coincidencia(s) y hay {n} para: {old[:70]!r}"
    h = h.replace(old, new, 1) if first_only else h.replace(old, new)

# 1) viewport + márgenes seguros (barra de estado / navegación)
rep('<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">',
    '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">')
assert h.index('</style>') < h.index('<body>')
rep('</style>', """
/* ---- Android nativo: márgenes seguros ---- */
:root{--sat:var(--safe-area-inset-top, env(safe-area-inset-top, 0px));--sab:var(--safe-area-inset-bottom, env(safe-area-inset-bottom, 0px));}
.topbar{height:calc(56px + var(--sat));padding-top:var(--sat);}
.tabs{top:calc(56px + var(--sat));}
.view{padding-bottom:calc(90px + var(--sab));}
.bottom-bar{padding-bottom:calc(10px + var(--sab));}
</style>""", count=2, first_only=True)

# 2) detección nativa + helpers (antes del bloque de alarmas)
NATIVE_BLOCK = r'''
/* ---- NATIVE (Android) ---- */
var NATIVE = !!(window.Capacitor && typeof Capacitor.isNativePlatform === "function" && Capacitor.isNativePlatform());
var LN = (NATIVE && Capacitor.Plugins) ? Capacitor.Plugins.LocalNotifications : null;
var schedChain = Promise.resolve();
var REMIND_MIN = 10; /* recordatori si la presa no s'ha registrat */

function chanId(tone){ return "dose_"+tone+"_v1"; }
function nativeDoseId(d, idx, reminder){ return d*100 + idx*2 + (reminder ? 1 : 0); }
function errText(e){ return (e && e.message) ? e.message : String(e); }

function nativeQueue(fn){
  schedChain = schedChain.then(fn).catch(function(e){ setDiag("✗ "+errText(e), "err"); });
  return schedChain;
}

function nativeEnsureChannels(){
  return Promise.all(Object.keys(TONES).map(function(k){
    return LN.createChannel({
      id: chanId(k), name: "Preses · "+TONES[k].label,
      description: "Avisos de cada presa de Todacitan",
      importance: 5, visibility: 1, vibration: true, sound: "tone_"+k+".wav"
    });
  }));
}

function nativeScheduleAll(){
  if(!NATIVE || !LN || !state) return Promise.resolve();
  return nativeQueue(function(){
    return LN.getPending().then(function(p){
      var pend = (p && p.notifications) ? p.notifications : [];
      return pend.length ? LN.cancel({ notifications: pend.map(function(n){ return { id:n.id }; }) }) : null;
    }).then(function(){
      if(!state.config.alarmsEnabled) return null;
      var tone = getTone(), now = Date.now(), list = [];
      for(var d=1; d<=25; d++){
        (function(d){
          var dayObj = state.days[d], parts = dayObj.date.split("-");
          dayObj.doses.forEach(function(dose, idx){
            if(dose.taken) return;
            var t = dose.scheduled.split(":");
            var at = new Date(+parts[0], +parts[1]-1, +parts[2], +t[0], +t[1], 0, 0).getTime();
            var base = { channelId: chanId(tone), smallIcon: "ic_stat_notify", iconColor: "#DC0028",
                         actionTypeId: "DOSE", autoCancel: true, extra: { day:d, idx:idx } };
            if(at > now + 1000){
              list.push(Object.assign({}, base, { id: nativeDoseId(d, idx, false),
                title: "Hora de la presa · Todacitan",
                body: "Dia "+d+" · presa de les "+dose.scheduled+"h. Toca per registrar-la.",
                schedule: { at: new Date(at), allowWhileIdle: true } }));
            }
            var rAt = at + REMIND_MIN*60000;
            if(rAt > now + 1000){
              list.push(Object.assign({}, base, { id: nativeDoseId(d, idx, true),
                title: "Presa pendent · Todacitan",
                body: "Encara no has registrat la presa de les "+dose.scheduled+"h (dia "+d+").",
                schedule: { at: new Date(rAt), allowWhileIdle: true } }));
            }
          });
        })(d);
      }
      if(!list.length){ setDiag("No queden preses futures per programar."); return null; }
      return LN.schedule({ notifications: list }).then(function(res){
        if(res && res.warning){
          setDiag("⚠ "+list.length+" avisos programats, però Android no permet alarmes exactes: poden endarrerir-se uns minuts. Activa «Alarmes i recordatoris» per a Todacitan als ajustos del mòbil.", "err");
        } else {
          setDiag("✓ "+list.length+" avisos programats al sistema: sonaran encara que l'app estigui tancada.", "ok");
        }
      });
    });
  });
}

function nativeCancelDose(day, idx){
  if(!LN) return;
  var ids = [nativeDoseId(day, idx, false), nativeDoseId(day, idx, true)];
  try{
    LN.cancel({ notifications: ids.map(function(i){ return { id:i }; }) }).catch(function(){});
    LN.removeDeliveredNotificationsById({ ids: ids }).catch(function(){});
  }catch(e){}
}

function nativeToggleAlarms(){
  if(state.config.alarmsEnabled){
    state.config.alarmsEnabled = false; saveState(); renderAlarmToggle();
    return nativeScheduleAll().then(function(){ setDiag("Alarmes desactivades. S'han cancel·lat els avisos programats."); });
  }
  if(!LN){ setDiag("✗ El connector de notificacions no està disponible en aquesta compilació.", "err"); return; }
  return LN.requestPermissions().then(function(perm){
    if(perm.display !== "granted"){
      setDiag("✗ Permís de notificacions denegat. Activa'l a Ajustos del mòbil → Aplicacions → Todacitan → Notificacions.", "err");
      return null;
    }
    return nativeEnsureChannels()
      .then(function(){ return LN.registerActionTypes({ types:[{ id:"DOSE", actions:[{ id:"taken", title:"Presa feta ✓" }] }] }); })
      .then(function(){ return LN.checkExactNotificationSetting(); })
      .then(function(ex){ if(ex && ex.exact_alarm === "denied") return LN.changeExactNotificationSetting(); })
      .then(function(){
        state.config.alarmsEnabled = true; saveState(); renderAlarmToggle();
        return nativeScheduleAll();
      });
  }).catch(function(e){ setDiag("✗ "+errText(e), "err"); });
}

function nativeTestAlarm(){
  state.config.alarmTone = document.getElementById("toneSelect").value;
  saveState();
  if(!LN){ setDiag("✗ El connector de notificacions no està disponible en aquesta compilació.", "err"); return; }
  return LN.requestPermissions().then(function(perm){
    if(perm.display !== "granted"){ setDiag("✗ Permís de notificacions denegat.", "err"); return null; }
    return nativeEnsureChannels().then(function(){
      return LN.schedule({ notifications:[{
        id: 999999, title: "Avís de prova · Todacitan",
        body: "Si sents aquest so, les alarmes funcionen.",
        channelId: chanId(getTone()), smallIcon: "ic_stat_notify", iconColor: "#DC0028",
        schedule: { at: new Date(Date.now()+5000), allowWhileIdle: true }
      }] });
    }).then(function(){ setDiag("✓ Avís de prova en 5 segons. Bloqueja el mòbil o surt de l'app per comprovar que sona.", "ok"); });
  }).catch(function(e){ setDiag("✗ "+errText(e), "err"); });
}

function nativeInit(){
  if(!NATIVE || !LN) return;
  nativeEnsureChannels()
    .then(function(){ return LN.registerActionTypes({ types:[{ id:"DOSE", actions:[{ id:"taken", title:"Presa feta ✓" }] }] }); })
    .catch(function(){});
  LN.addListener("localNotificationActionPerformed", function(ev){
    var ex = ev && ev.notification && ev.notification.extra;
    if(!ex || !state || !state.days[ex.day]) return;
    if(ev.actionId === "taken" && !state.days[ex.day].doses[ex.idx].taken){
      markTaken(ex.day, ex.idx);
    }
    openDay = ex.day;
    switchView("calendar");
  });
  if(state && state.config.alarmsEnabled) nativeScheduleAll();
}

/* ---- ALARMES ---- */'''
rep('\n/* ---- ALARMES ---- */', NATIVE_BLOCK)

# 3) ramas nativas en funciones existentes
rep('function registerSW(){\n  if(!("serviceWorker" in navigator)) return;',
    'function registerSW(){\n  if(NATIVE || !("serviceWorker" in navigator)) return;')
rep('function checkAlarms(){\n  if(!state || !state.config.alarmsEnabled) return;',
    'function checkAlarms(){\n  if(NATIVE) return; /* en nativo avisa el sistema */\n  if(!state || !state.config.alarmsEnabled) return;')
rep('function toggleAlarms(){\n  unlockAudio();',
    'function toggleAlarms(){\n  unlockAudio();\n  if(NATIVE) return nativeToggleAlarms();')
rep('function testAlarm(){\n  unlockAudio();',
    'function testAlarm(){\n  unlockAudio();\n  if(NATIVE) return nativeTestAlarm();')
rep('  var supported = ("Notification" in window);\n  var on = !!state.config.alarmsEnabled;',
    '  var supported = NATIVE || ("Notification" in window);\n  var on = !!state.config.alarmsEnabled;')
rep('} else if(on && Notification.permission !== "granted"){',
    '} else if(!NATIVE && on && Notification.permission !== "granted"){')

# 4) marcar / deshacer / cambiar tono
rep('  dose.taken = true;\n  dose.takenAt = nowHHMM();\n  saveState();\n  renderCalendar();',
    '  dose.taken = true;\n  dose.takenAt = nowHHMM();\n  saveState();\n  if(NATIVE) nativeCancelDose(day, doseIdx);\n  renderCalendar();')
rep('  dose.taken = false;\n  dose.takenAt = null;\n  saveState();\n  renderCalendar();',
    '  dose.taken = false;\n  dose.takenAt = null;\n  saveState();\n  if(NATIVE) nativeScheduleAll();\n  renderCalendar();')
rep('  state.config.alarmTone = this.value;\n  saveState();\n  playTone(this.value);',
    '  state.config.alarmTone = this.value;\n  saveState();\n  playTone(this.value);\n  if(NATIVE) nativeScheduleAll();')

# 5) exportar informe: en el WebView nativo la descarga por <a download> no funciona -> Compartir
rep('function exportReport(){\n  var html = buildExportHtml();',
    '''function exportNativeReport(html){
  var FS = Capacitor.Plugins.Filesystem, SH = Capacitor.Plugins.Share;
  var name = "informe_seguiment_todacitan_"+todayISO()+".html";
  return FS.writeFile({ path: name, data: html, directory: "CACHE", encoding: "utf8" }).then(function(r){
    return SH.share({ title: "Informe de seguiment Todacitan", text: "Informe de seguiment del tractament", files: [r.uri], dialogTitle: "Exportar informe" });
  }).catch(function(e){
    if(e && /cancel/i.test(errText(e))) return;
    alert("No s'ha pogut exportar l'informe: "+errText(e));
  });
}

function exportReport(){
  var html = buildExportHtml();
  if(NATIVE && window.Capacitor.Plugins && Capacitor.Plugins.Filesystem && Capacitor.Plugins.Share){ return exportNativeReport(html); }''')

# 6) texto de ayuda y arranque
rep('  } else {\n    document.getElementById("cfgDate").value = todayISO();\n  }',
    '  } else {\n    document.getElementById("cfgDate").value = todayISO();\n  }\n  nativeInit(); /* siempre: canales, acción de la notificación y reprogramación */')
rep('(function boot(){\n  registerSW();',
    '''(function boot(){
  registerSW();
  if(NATIVE){
    var hint = document.querySelector(".alarm-hint");
    if(hint) hint.textContent = "Les alarmes les programa el sistema Android: sonen a l'hora exacta de cada presa encara que l'app estigui tancada o el mòbil bloquejat. Si no registres la presa, hi ha un recordatori als 10 minuts. Pots marcar-la directament des de la notificació.";
  }''')
rep('    if(!document.hidden && state){ checkAlarms(); }',
    '    if(!document.hidden && state){ checkAlarms(); if(NATIVE && state.config.alarmsEnabled) nativeScheduleAll(); }')

open(DST, "w", encoding="utf-8").write(h)
print("OK", len(h), "bytes")
