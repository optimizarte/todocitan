"""Genera los sonidos de alarma (WAV) y los iconos de la app. Se ejecuta una sola vez; el resultado se guarda en resources/."""
import wave, struct, os
import numpy as np
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "resources", "raw")
SR = 22050

# (frecuencia Hz, inicio s, duración s, onda, volumen)
TONES = {
    "classic": [(880,0,.35,"sine",.9),(880,.5,.35,"sine",.9),(880,1.0,.35,"sine",.9)],
    "bell":    [(1318,0,.5,"sine",.9),(1046,.45,.5,"sine",.85),(1318,.9,.5,"sine",.9),(1046,1.35,.7,"sine",.8)],
    "digital": [(1500,0,.12,"square",.45),(1500,.2,.12,"square",.45),(1500,.4,.12,"square",.45),(1900,.7,.25,"square",.45)],
    "soft":    [(523,0,.9,"triangle",.9),(659,.5,.9,"triangle",.85),(784,1.0,1.2,"triangle",.8)],
    "urgent":  [(988,0,.18,"sawtooth",.5),(740,.2,.18,"sawtooth",.5),(988,.4,.18,"sawtooth",.5),
                (740,.6,.18,"sawtooth",.5),(988,.8,.18,"sawtooth",.5),(740,1.0,.18,"sawtooth",.5)],
}

def wave_fn(kind, phase):
    if kind == "sine": return np.sin(phase)
    if kind == "square": return np.sign(np.sin(phase))
    if kind == "sawtooth": return 2.0*((phase/(2*np.pi)) % 1.0) - 1.0
    if kind == "triangle": return 2.0*np.abs(2.0*((phase/(2*np.pi)) % 1.0) - 1.0) - 1.0
    raise ValueError(kind)

def render(notes, repeats=2, gap=0.5):
    pattern_len = max(s+d for _,s,d,_,_ in notes) + 0.1
    total = repeats*pattern_len + (repeats-1)*gap
    buf = np.zeros(int(total*SR)+SR//10)
    for r in range(repeats):
        off = r*(pattern_len+gap)
        for f, s, d, kind, vol in notes:
            n = int(d*SR); t = np.arange(n)/SR
            sig = wave_fn(kind, 2*np.pi*f*t)
            att = np.minimum(1.0, t/0.015)          # ataque 15 ms
            rel = np.minimum(1.0, (d-t)/0.08)        # relajación 80 ms
            env = np.clip(att*rel, 0, 1)
            i0 = int((off+s)*SR)
            buf[i0:i0+n] += sig*env*vol
    peak = np.max(np.abs(buf)) or 1.0
    return buf/peak*0.85

os.makedirs(RAW, exist_ok=True)
for name, notes in TONES.items():
    data = (render(notes)*32767).astype("<i2")
    path = os.path.join(RAW, f"tone_{name}.wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(data.tobytes())
    print(path, os.path.getsize(path)//1024, "KB")

# ---------- ICONOS ----------
RED = (220, 0, 40, 255); DARK = (32, 32, 32, 255); GRAY = (154, 154, 154, 255); WHITE = (255, 255, 255, 255)

def sign(size):
    """Pictograma 'no fumar' propio, sobre fondo transparente, ocupando todo el lienzo."""
    S = size*4
    img = Image.new("RGBA", (S, S), (0,0,0,0)); d = ImageDraw.Draw(img)
    c = S/2; ring = S*0.46; w = S*0.085
    # cigarrillo (capa rotada)
    layer = Image.new("RGBA", (S, S), (0,0,0,0)); ld = ImageDraw.Draw(layer)
    L, H = S*0.50, S*0.085
    x0, y0 = c-L/2, c+S*0.035
    ld.rounded_rectangle([x0, y0, x0+L, y0+H], radius=H*0.3, fill=DARK)
    ld.rounded_rectangle([x0, y0, x0+L*0.26, y0+H], radius=H*0.3, fill=RED)
    layer = layer.rotate(28, resample=Image.BICUBIC, center=(c, c))
    img.alpha_composite(layer)
    # humo
    for dx, dy, sc in ((0.20, -0.04, 1.0), (0.31, -0.02, 0.8)):
        bx = c + S*dx; by = c + S*dy
        d.arc([bx-S*0.07*sc, by-S*0.20*sc, bx+S*0.07*sc, by], 100, 330, fill=GRAY, width=int(S*0.025))
    # anillo + barra
    d.ellipse([c-ring, c-ring, c+ring, c+ring], outline=RED, width=int(w))
    k = ring*0.707
    d.line([c-k, c+k, c+k, c-k], fill=RED, width=int(w), joint="curve")
    return img.resize((size, size), Image.LANCZOS)

def legacy(size, round_=False):
    img = Image.new("RGBA", (size, size), (0,0,0,0)); d = ImageDraw.Draw(img)
    if round_: d.ellipse([0,0,size-1,size-1], fill=WHITE)
    else: d.rounded_rectangle([0,0,size-1,size-1], radius=size*0.22, fill=WHITE)
    s = sign(int(size*0.78)); img.alpha_composite(s, ((size-s.width)//2, (size-s.height)//2))
    return img

def foreground(size):
    img = Image.new("RGBA", (size, size), (0,0,0,0))
    s = sign(int(size*0.56)); img.alpha_composite(s, ((size-s.width)//2, (size-s.height)//2))
    return img

DENS = {"mdpi":(48,108), "hdpi":(72,162), "xhdpi":(96,216), "xxhdpi":(144,324), "xxxhdpi":(192,432)}
for dens, (leg, fg) in DENS.items():
    out = os.path.join(ROOT, "resources", f"mipmap-{dens}"); os.makedirs(out, exist_ok=True)
    legacy(leg).save(os.path.join(out, "ic_launcher.png"))
    legacy(leg, True).save(os.path.join(out, "ic_launcher_round.png"))
    foreground(fg).save(os.path.join(out, "ic_launcher_foreground.png"))
print("iconos OK")
