// Prepara el proyecto Android (Capacitor): genera la plataforma, copia iconos y sonidos,
// añade permisos, fija la firma y sincroniza la web. Después se compila con Gradle.
import { execSync } from "node:child_process";
import { cpSync, existsSync, readFileSync, writeFileSync, readdirSync, statSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const run = (cmd) => { console.log("$ " + cmd); execSync(cmd, { cwd: ROOT, stdio: "inherit" }); };
const edit = (file, fn) => { const p = join(ROOT, file); const a = readFileSync(p, "utf8"); const b = fn(a); if (a === b) throw new Error("Sin cambios en " + file); writeFileSync(p, b); };

// 1) Plataforma Android
if (!existsSync(join(ROOT, "android"))) run("npx cap add android");

// 2) Recursos propios: sonidos (res/raw), icono de notificación, iconos de la app
const RES = join(ROOT, "android/app/src/main/res");
cpSync(join(ROOT, "resources"), RES, { recursive: true, force: true });
console.log("Recursos copiados:", readdirSync(join(RES, "raw")).join(", "));

// 3) Permisos: vibración y alarma exacta automática (Android 13+)
edit("android/app/src/main/AndroidManifest.xml", (s) => {
  if (s.includes("USE_EXACT_ALARM")) return s + " ";
  return s.replace(
    '<uses-permission android:name="android.permission.INTERNET" />',
    '<uses-permission android:name="android.permission.INTERNET" />\n' +
    '    <uses-permission android:name="android.permission.VIBRATE" />\n' +
    '    <uses-permission android:name="android.permission.USE_EXACT_ALARM" />');
});

// 4) Firma fija (misma clave en cada compilación => las actualizaciones se instalan encima sin perder datos)
//    + número de versión creciente
edit("android/app/build.gradle", (s) => {
  if (s.includes("todacitan.keystore")) return s + " ";
  s = s.replace("android {\n    namespace",
`android {
    signingConfigs {
        debug {
            storeFile file("../../keystore/todacitan.keystore")
            storePassword "todacitan"
            keyAlias "todacitan"
            keyPassword "todacitan"
        }
    }
    namespace`);
  const n = parseInt(process.env.BUILD_NUMBER || "1", 10) || 1;
  return s.replace(/versionCode \d+/, "versionCode " + n).replace(/versionName "[^"]*"/, 'versionName "1.' + n + '"');
});

// 5) Sincronizar web + plugins
run("npx cap sync android");
console.log("OK: proyecto Android listo. Compila con: cd android && ./gradlew assembleDebug");
